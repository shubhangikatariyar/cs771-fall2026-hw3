# Modified from https://github.com/madebyollin/taesd/blob/main/taesd.py

"""
Tiny AutoEncoder for Stable Diffusion
(DNN for encoding / decoding SD's latent space)
"""
import torch
import torch.nn as nn

def conv(n_in, n_out, **kwargs):
    return nn.Conv2d(n_in, n_out, 3, padding=1, **kwargs)

class Clamp(nn.Module):
    def forward(self, x):
        return torch.tanh(x / 3) * 3

class Block(nn.Module):
    def __init__(self, n_in, n_out):
        super().__init__()
        self.conv = nn.Sequential(
            conv(n_in, n_out),
            nn.ReLU(),
            conv(n_out, n_out),
            nn.ReLU(),
            conv(n_out, n_out)
        )
        self.skip = nn.Conv2d(
            n_in, n_out, 1, bias=False
        ) if n_in != n_out else nn.Identity()
        self.fuse = nn.ReLU()
    def forward(self, x):
        return self.fuse(self.conv(x) + self.skip(x))

def Encoder(latent_channels=4):
    return nn.Sequential(
        conv(3, 64), Block(64, 64),
        conv(64, 64, stride=2, bias=False),
        Block(64, 64), Block(64, 64), Block(64, 64),
        conv(64, 64, stride=2, bias=False),
        Block(64, 64), Block(64, 64), Block(64, 64),
        conv(64, 64, stride=2, bias=False),
        Block(64, 64), Block(64, 64), Block(64, 64),
        conv(64, latent_channels),
    )

def Decoder(latent_channels=4):
    return nn.Sequential(
        Clamp(),
        conv(latent_channels, 64), nn.ReLU(),
        Block(64, 64), Block(64, 64), Block(64, 64),
        nn.Upsample(scale_factor=2), conv(64, 64, bias=False),
        Block(64, 64), Block(64, 64), Block(64, 64),
        nn.Upsample(scale_factor=2), conv(64, 64, bias=False),
        Block(64, 64), Block(64, 64), Block(64, 64),
        nn.Upsample(scale_factor=2), conv(64, 64, bias=False),
        Block(64, 64), conv(64, 3),
    )

class TAESD(nn.Module):

    def __init__(
        self,
        encoder_path="taesd_encoder.pth",
        decoder_path="taesd_decoder.pth",
        latent_channels=None
    ):
        """Initialize pretrained TAESD on the given device from the given checkpoints."""
        super().__init__()
        if latent_channels is None:
            latent_channels = self.guess_latent_channels(str(encoder_path))
        self.encoder = Encoder(latent_channels)
        self.decoder = Decoder(latent_channels)
        if encoder_path is not None:
            self.encoder.load_state_dict(
                torch.load(encoder_path, map_location="cpu", weights_only=True)
            )
        if decoder_path is not None:
            self.decoder.load_state_dict(
                torch.load(decoder_path, map_location="cpu", weights_only=True)
            )
        self.patch_size = 8
        self.latent_channels = latent_channels

    def guess_latent_channels(self, encoder_path):
        """guess latent channel count based on encoder filename"""
        if "taef1" in encoder_path:
            return 16
        if "taesd3" in encoder_path:
            return 16
        return 4

    @torch.compile
    def encode(self, x):
        x = self.encoder(x)
        return x

    @torch.compile
    def decode(self, x):
        x = self.decoder(x)
        return x
